# odeta/__init__.py
from .a import database
