# odeta/__init__.py
from .a import db, Table
